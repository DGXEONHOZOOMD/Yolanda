module.exports = {
  TOKEN_USER: "8763413992:AAGHLdEkzr1d4F-JokJuuojP4B1SDwKTu7U:", //Ganti Token Bot
  ModuleApiBot: "AphoppisApi77", // Api Bot Jangan Ganti 
};